# Stripe-Payment-integration-PHP

<a href="https://github.com/IANirab/Stripe-Payment-integration-PHP" alt="Build">
<img alt="" src="https://img.shields.io/badge/build-passing-brightgreen.svg"></a>

Stripe Payment Gateway Integration in PHP

Go charge.php & change api key
