//JS ONLY! - HARSH THAKKAR

$.getScript('assets/js/alerts/sweet.js');
$.getScript('assets/js/alerts/alert.js');