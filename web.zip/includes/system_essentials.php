<?php
error_reporting(0);
session_start();
include("./system/db/DocAppointDatabaseConnection.php");
date_default_timezone_set("America/Montreal");
?>